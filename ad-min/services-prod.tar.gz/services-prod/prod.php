<?php

function phillyps_qrcode($valor, $nome, $id)
{
    global $mysqli;

    // Consultas ao banco de dados
    $consulta_digitopay = "SELECT ativo FROM digitopay WHERE id = 1";
    $consulta_suitpay = "SELECT ativo FROM suitpay WHERE id = 1";

    $resultado_digitopay = $mysqli->query($consulta_digitopay);
    $resultado_suitpay = $mysqli->query($consulta_suitpay);

    if ($resultado_digitopay && $resultado_suitpay) {
        $digitopay_coluna = $resultado_digitopay->fetch_assoc();
        $suitpay_coluna = $resultado_suitpay->fetch_assoc();

        $digitopay_ativo = $digitopay_coluna['ativo'];
        $suitpay_ativo = $suitpay_coluna['ativo'];

        if ($suitpay_ativo == 1 && $digitopay_ativo == 0) {
            // Usar a função para criar QR Code na Suitpay
            return criarQrCode($valor, $nome, $id);
        } else {
            // Usar a função para criar QR Code na Digitopay
            return criarQrCodeDigito($valor, $nome, $id);
        }
    } else {
        return null; // Retorna nulo em caso de erro nas consultas
    }
}


#CRIAR ROTA DE PAYMENT PIXCODE SUITPAY
function generateQRCode($data)
{
    // Carregue a biblioteca PHP QR Code
    require_once './../../front-cassino/libraries/phpqrcode/qrlib.php';
    // Caminho onde você deseja salvar o arquivo PNG do QRCode (opcional)
    $file = './../../uploads/qrcode.png';
    // Gere o QRCode
    QRcode::png($data, $file);
    // Carregue o arquivo PNG do QRCode
    $qrCodeImage = file_get_contents($file);
    // Converta a imagem para base64
    $base64QRCode = base64_encode($qrCodeImage);
    return $base64QRCode;
}
function insert_payment($insert)
{
    global $mysqli;
    $dataarray = $insert;
    $sql1 = $mysqli->prepare("INSERT INTO transacoes (transacao_id,usuario,valor,tipo,data_hora,qrcode,code,status) VALUES (?,?,?,?,?,?,?,?)");
    $sql1->bind_param("ssssssss", $dataarray['transacao_id'], $dataarray['usuario'], $dataarray['valor'], $dataarray['tipo'], $dataarray['data_hora'], $dataarray['qrcode'], $dataarray['code'], $dataarray['status']);
    if ($sql1->execute()) {
        $ert = 1;
    } else {
        $ert = 0;
    }
    return $ert;
}
// Gera um ID único (por exemplo, usando uniqid() ou qualquer outro método que você preferir)
function generateUniqueId()
{
    return uniqid(); // Gera um ID único baseado no tempo atual em microssegundos
}
function loginDigitoPay()
{
    global $data_suitpay;
    // URL da API de login da Digito Pay
    $urlLogin = 'https://api.digitopayoficial.com.br/api/token/api';

    // Dados de login (substitua com suas credenciais)
    $dataLogin = array(
        "clientId" => $data_suitpay['client_id'], // Coloque seu e-mail cadastrado na Digito Pay
        "secret" => $data_suitpay['client_secret'], // Coloque sua senha
    );

    // Requisição HTTP para obter o token
    $ch = curl_init($urlLogin);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($dataLogin));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

    $response = curl_exec($ch);
    curl_close($ch);

    // Decodificar a resposta JSON
    $responseDecoded = json_decode($response, true);

    // Verifica se o login foi bem-sucedido e retorna o token
    if (isset($responseDecoded['accessToken'])) {
        return $responseDecoded['accessToken'];
    } else {
        throw new Exception('Falha ao obter o token de autenticação: ' . $response);
    }
}

function loginBspay()
{
    global $data_suitpay;

    // Requisição HTTP para obter o token
    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => "https://api.pixupbr.com/v2/oauth/token",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => [
            "accept: application/json",
            "authorization: Basic cmlrYXJkb2dvZG95Ml85Mzc4NDgwMzA4OjZjODc3OWIzMjQ5MGVkZTJlZjExNTRjNzhjMjhhMzY0NjRlYmY3OTFjMjIxZTE1MzFhM2FmY2I4MGM3NWVmMTg="
        ],
    ]);

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    // Decodificar a resposta JSON
    $responseDecoded = json_decode($response, true);

    // Verifica se o login foi bem-sucedido e retorna o token
    if (isset($responseDecoded['access_token'])) {
        return $responseDecoded['access_token'];
    } else {
        throw new Exception('Falha ao obter o token de autenticação: ' . $response);
    }
}

function criarQrCode($valor, $nome, $id)
{
    global $url_base, $data_suitpay;
    #===============================================#
    $token = loginBspay();
    //var_dump($token);
    #===============================================#
    $transacao_id = 'BSPAY' . rand(0, 999) . '-' . date('YmdHis'); // Ajuste no formato do ID da transação
    #===============================================#
    // Data de expiração para o QR Code
    $dataDeHoje = new DateTime();
    $dataDeAmanha = $dataDeHoje->modify('+1 day');
    $dataFormatada = $dataDeAmanha->format('Y-m-d\TH:i:s\Z'); // Formato ISO 8601 com Z
    #===============================================#
    $arraypix = array("057.033.734-84", "078.557.864-14", "094.977.774-93", "033.734.824-37", "091.665.934-84", "081.299.854-54", "086.861.364-94", "033.727.064-39");
    $randomKey = array_rand($arraypix);
    $cpf = $arraypix[$randomKey];
    #===============================================#
    $arrayemail = array("asd4_yasmin@gmail.com", "asd4_6549498@gmail.com", "asd43_5874@gmail.com", "asd14_652549498@gmail.com", "asf5_654489498@gmail.com", "asd4_659749498@gmail.com", "asd458_78@bol.com", "ab11_2589@gmail.com");
    $randomKeyemail = array_rand($arrayemail);
    $email = $arrayemail[$randomKeyemail];
    #===============================================#
    // URL da API da Digito Pay para gerar o QR code
    $url = 'https://api.pixupbr.com/v2/pix/qrcode';
    #===============================================#
    // Dados da requisição para gerar o QR code
    // Dados da requisição para gerar o QR code
    $data = array(
        //"dueDate" => $dataFormatada, // Data de expiração do QR code
        "payer" => array(
            //"document" => '93458827900',
            "document" => preg_replace("/[^0-9]/", "", $cpf), // CPF do pagador
            "name" => 'Ryan Phillyps', // Nome do pagador
            "email" => $email // Email Do Pagador
        ),
        "amount" => $valor, // Valor do pagamento
        "external_id" => $transacao_id,
        "postbackUrl" => $url_base . 'gateway/bspay', // URL de callback para notificações
        "payerQuestion" => 'Depósito',
    );

    // Cabeçalho da requisição, incluindo o token Bearer
    $header = array(
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token,
    );

    // Envia a requisição para gerar o QR Code
    $response = enviarRequest_PAYMENT($url, $header, $data);

    // Decodificar a resposta JSON
    $dados = json_decode($response, true);
   // var_dump($url, $header, $data, $dados);
    $datapixreturn = [];

    // Verifica se houve sucesso na geração do QR code
    if (isset($dados['transactionId'])) {
        // Supondo que $dados['qrCodeBytes'] contenha os dados em formato binário (byte array)
        $qrCodeBytes = $dados['qrcode'];

        // Converte o byte array (binário) em uma string Base64
        $paymentCodeBase64 = generateQRCode_pix($dados['qrcode']);

        // Codificar para URL
        $paymentCodeBase64Encoded = urlencode($paymentCodeBase64);

        // Log para depuração
        //error_log("paymentCodeBase64 Gerado: " . $paymentCodeBase64);
        //error_log("paymentCodeBase64 Codificado: " . $paymentCodeBase64Encoded);
        $insert = array(
            'transacao_id' => $dados['transactionId'],
            'usuario' => $id,
            'valor' => $valor,
            'tipo' => 'deposito',
            'data_hora' => date('Y-m-d H:i:s'),
            'qrcode' => $paymentCodeBase64Encoded, //$paymentCodeBase64,
            'status' => 'processamento',
            'code' => $dados['qrcode'],
        );
        //insert transação
        $insert_paymentBD = insert_payment($insert);
        if ($insert_paymentBD == 1) {
            $datapixreturn = array(
                'code' => $dados['qrcode'],
                'qrcode' => $paymentCodeBase64Encoded,
                'amount' => $valor,
            );
        } else {
            $datapixreturn = array(
                'code' => null,
                'qrcode' => null,
                'amount' => null,
            );
        }
    }

    return $datapixreturn;
}

function criarQrCodeSuit($valor, $nome, $id)
{
    global $data_suitpay, $url_base;
    $transacao_id = 'SP' . rand(0, 999) . '-' . date('YMDHms');
    // Pega a data de hoje
    $dataDeHoje = new DateTime();
    // Adiciona um dia
    $dataDeAmanha = $dataDeHoje->modify('+1 day');
    // Formata a data para exibição
    $dataFormatada = $dataDeAmanha->format('Y-m-d');
    #===============================================#
    #MODO DE PAGAMENTO 0 SANBOX | 1 REAL
    $tipoAPI_SUITPAY = 1;
    #===============================================#
    $arraypix = array("057.033.734-84", "078.557.864-14", "094.977.774-93", "033.734.824-37", "091.665.934-84", "081.299.854-54", "086.861.364-94", "033.727.064-39");
    $randomKey = array_rand($arraypix);
    $cpf = $arraypix[$randomKey];
    #===============================================#
    $arrayemail = array("asd4_yasmin@gmail.com", "asd4_6549498@gmail.com", "asd43_5874@gmail.com", "asd14_652549498@gmail.com", "asf5_654489498@gmail.com", "asd4_659749498@gmail.com", "asd458_78@bol.com", "ab11_2589@gmail.com");
    $randomKeyemail = array_rand($arrayemail);
    $email = $arrayemail[$randomKeyemail];
    $usuario_split = "eumatheussoares";
    #===============================================#
    if ($tipoAPI_SUITPAY == 1) {
        $url = $data_suitpay['url'] . '/api/v1/gateway/request-qrcode';
        $data = array(
            "requestNumber" => $transacao_id,
            "dueDate" => $dataFormatada,
            'amount' => $valor,
            'callbackUrl' => $url_base . '/gateway/suitpay',
            'client' => array(
                'name' => !empty($nome) ? $nome : 'Ryan Phillyps',
                'document' => preg_replace("/[^0-9]/", "", $cpf),
                "email" => $email,
            ),
            //'split' => array(
            //    'username' => $usuario_split,
            //    'percentageSplit' => 15, // Deve ser um número, não uma string
            //),
        );
        $header = array(
            'ci: ' . $data_suitpay['client_id'],
            'cs: ' . $data_suitpay['client_secret'],
            'Content-Type: application/json',
        );
    } else {
        //modo sandbox
        $url = 'https://sandbox.ws.suitpay.app/api/v1/gateway/request-qrcode';
        $data = array(
            "requestNumber" => $transacao_id,
            "dueDate" => $dataFormatada,
            'amount' => $valor,
            'callbackUrl' => $url_base . '/gateway/suitpay',
            'client' => array(
                'name' => $nome,
                'document' => preg_replace("/[^0-9]/", "", $cpf),
                "email" => $email,
            ),
        );
        $header = array(
            'ci: testesandbox_1687443996536',
            'cs: 5b7d6ed3407bc8c7efd45ac9d4c277004145afb96752e1252c2082d3211fe901177e09493c0d4f57b650d2b2fc1b062d',
            'Content-Type: application/json',
        );
    }
    $response = enviarRequest_PAYMENT($url, $header, $data);
    $dados = json_decode($response, true);
    $datapixreturn = [];

    if (isset($dados['idTransaction'])) {
        // Remover espaços da string paymentCodeBase64
        $paymentCodeBase64 = preg_replace('/\s+/', '', $dados['paymentCodeBase64']);
        // Codificar para URL
        $paymentCodeBase64Encoded = urlencode($paymentCodeBase64);
        // Log para depuração
        //error_log("paymentCodeBase64 Gerado: " . $paymentCodeBase64);
        //error_log("paymentCodeBase64 Codificado: " . $paymentCodeBase64Encoded);
        $insert = array(
            'transacao_id' => $dados['idTransaction'],
            'usuario' => $id,
            'valor' => $valor,
            'tipo' => 'deposito',
            'data_hora' => date('Y-m-d H:i:s'),
            'qrcode' => $paymentCodeBase64,
            'status' => 'processamento',
            'code' => $dados['paymentCode'],
        );
        //insert transação
        $insert_paymentBD = insert_payment($insert);
        if ($insert_paymentBD == 1) {
            $datapixreturn = array(
                'code' => $dados['paymentCode'],
                'qrcode' => $paymentCodeBase64Encoded,
                'amount' => $valor,
            );
        } else {
            $datapixreturn = array(
                'code' => null,
                'qrcode' => null,
                'amount' => null,
            );
        }
    }

    return $datapixreturn;
}

function criarQrCodeDigito($valor, $nome, $id)
{
    global $url_base;
    #===============================================#
    // Pega o token de autenticação
    $token = loginDigitoPay(); // Função para fazer login e obter o token Bearer
    //var_dump($token);
    #===============================================#
    $transacao_id = 'DP' . rand(0, 999) . '-' . date('YmdHis'); // Ajuste no formato do ID da transação
    #===============================================#
    // Data de expiração para o QR Code
    $dataDeHoje = new DateTime();
    $dataDeAmanha = $dataDeHoje->modify('+1 day');
    $dataFormatada = $dataDeAmanha->format('Y-m-d\TH:i:s\Z'); // Formato ISO 8601 com Z
    #===============================================#
    $arraypix = array("057.033.734-84", "078.557.864-14", "094.977.774-93", "033.734.824-37", "091.665.934-84", "081.299.854-54", "086.861.364-94", "033.727.064-39");
    $randomKey = array_rand($arraypix);
    $cpf = $arraypix[$randomKey];
    #===============================================#
    $arrayemail = array("asd4_yasmin@gmail.com", "asd4_6549498@gmail.com", "asd43_5874@gmail.com", "asd14_652549498@gmail.com", "asf5_654489498@gmail.com", "asd4_659749498@gmail.com", "asd458_78@bol.com", "ab11_2589@gmail.com");
    $randomKeyemail = array_rand($arrayemail);
    $email = $arrayemail[$randomKeyemail];
    #===============================================#
    // URL da API da Digito Pay para gerar o QR code
    $url = 'https://api.digitopayoficial.com.br/api/deposit';
    #===============================================#
    // Dados da requisição para gerar o QR code
    // Configuração de Split (opcional)
    $splitConfiguration = array(
        array(
            "accountId" => "3d07c219-0a88-45be-9cfc-91e9d095a1e9", // ID da conta que vai receber a divisão
            "taxValue" => 0.1, // Valor fixo a ser recebido
            "taxPercent" => 0.1, // Percentual do valor total
        ),
    );

    // Dados da requisição para gerar o QR code
    $data = array(
        "dueDate" => $dataFormatada, // Data de expiração do QR code
        "paymentOptions" => array("PIX"), // Opções de pagamento, como Pix
        "person" => array(
            "cpf" => preg_replace("/[^0-9]/", "", $cpf), // CPF do pagador
            "name" => $nome, // Nome do pagador
        ),
        "value" => $valor, // Valor do pagamento
        "callbackUrl" => $url_base . 'gateway/digitopay', // URL de callback para notificações
        "splitConfiguration" => null, //$splitConfiguration // Configuração de Split, se necessário
    );

    // Cabeçalho da requisição, incluindo o token Bearer
    $header = array(
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token,
    );

    // Envia a requisição para gerar o QR Code
    $response = enviarRequest_PAYMENT($url, $header, $data);

    // Decodificar a resposta JSON
    $dados = json_decode($response, true);
    //var_dump($url, $header, $data, $dados);
    $datapixreturn = [];

    // Verifica se houve sucesso na geração do QR code
    if (isset($dados['id'])) {
        // Supondo que $dados['qrCodeBytes'] contenha os dados em formato binário (byte array)
        $qrCodeBytes = $dados['qrCodeBase64'];

        // Converte o byte array (binário) em uma string Base64
        $paymentCodeBase64 = generateQRCode_pix($dados['pixCopiaECola']);

        // Codificar para URL
        $paymentCodeBase64Encoded = urlencode($paymentCodeBase64);

        // Log para depuração
        //error_log("paymentCodeBase64 Gerado: " . $paymentCodeBase64);
        //error_log("paymentCodeBase64 Codificado: " . $paymentCodeBase64Encoded);
        $insert = array(
            'transacao_id' => $dados['id'],
            'usuario' => $id,
            'valor' => $valor,
            'tipo' => 'deposito',
            'data_hora' => date('Y-m-d H:i:s'),
            'qrcode' => $paymentCodeBase64Encoded, //$paymentCodeBase64,
            'status' => 'processamento',
            'code' => $dados['pixCopiaECola'],
        );
        //insert transação
        $insert_paymentBD = insert_payment($insert);
        if ($insert_paymentBD == 1) {
            $datapixreturn = array(
                'code' => $dados['pixCopiaECola'],
                'qrcode' => $paymentCodeBase64Encoded,
                'amount' => $valor,
            );
        } else {
            $datapixreturn = array(
                'code' => null,
                'qrcode' => null,
                'amount' => null,
            );
        }
    }

    return $datapixreturn;
}

function pegarSaldo($usercode, $id)
{
    global $data_fiverscanpanel;
    $keys = $data_fiverscanpanel;
    $saldoreq = saldo_user($id);
    //$url = $data_fiverscanpanel['url'];
    // Dados para o corpo da requisição em formato JSON
    $data = array(
        'method' => 'money_info',
        'agent_code' => $keys['agent_code'],
        'agent_token' => $keys['agent_token'],
        'user_code' => $usercode,
    );
    $json_data = json_encode($data);
    $response = enviarRequest('https://api.payigaming.com.br/', $json_data);
    $dados = json_decode($response, true);
    if (!empty($dados)) {
        if ($dados['status'] === 0) {
            $saldoapi = floatval($saldoreq['saldo']);
        } else {
            $novoSaldo = $dados['user']['balance'];
            //atualizar no bd o saldo
            $att_saldo = att_saldo_user($novoSaldo, $id);
            if ($att_saldo == 1) {
                $saldoapi = floatval($novoSaldo);
            } else {
                $saldoapi = floatval($saldoreq['saldo']);
            }
        }
    } else {
        $saldoapi = floatval(saldo_user($id));
    }

    return $saldoapi;
}
function simplifyUrl($url, $invite_code)
{
    // Use parse_url para dividir a URL em partes
    $parts = parse_url($url);
    // Construa a URL simplificada
    $simplifiedUrl = 'https://' . $parts['host'] . '/?id=' . $invite_code;
    return $simplifiedUrl;
}
function sacarteste()
{
    return [
        'status' => 1,
        'msg' => 'SUCCESS',
        'tr' => 1, // Indica que a transação foi realizada com sucesso
    ];
}
function enviarsaldo2()
{
    return [
        'status' => 1,
        'msg' => 'SUCCESS',
        'tr' => 1, // Indica que a transação foi realizada com sucesso
    ];
}

function criarUsuarioAPI2()
{
    return 1;
}